Purpose of JS files:

main.js: Main BlooketUI hack, for max stealth don't use get all answers correct hack
get-all-answers.js: Stealth version of BlooketUI answer hack, doesn't change question